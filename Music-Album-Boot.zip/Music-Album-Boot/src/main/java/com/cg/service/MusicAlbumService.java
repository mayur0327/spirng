package com.cg.service;

import com.cg.entity.MusicAlbum;

public interface MusicAlbumService {

	MusicAlbum saveAlbum(MusicAlbum m);

	MusicAlbum get(int id);

	MusicAlbum update(int id, MusicAlbum mobj);

	String delete(int id);
	
	public Iterable<MusicAlbum> getAll();

}
