package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.MusicAlbum;
import com.cg.repo.MusicAlbumRepo;

@Repository
@Transactional
public class MusicAlbumServiceImpl implements MusicAlbumService {

	@Autowired
	private MusicAlbumRepo repo;

	@Override
	public MusicAlbum saveAlbum(MusicAlbum m) {
		return repo.save(m);
	}

	@Override
	public MusicAlbum get(int id) {
		return repo.findOne(id);
	}

	@Override
	public MusicAlbum update(int id, MusicAlbum mobj) {
		mobj.setAlbumId(id);
		repo.save(mobj);
		return mobj;
	}
	
	@Override
	public String delete(int id) {
		MusicAlbum mobj = repo.findOne(id);
		repo.delete(mobj);
		return "Deleted Successfully.!";

	}

	@Override
	public Iterable<MusicAlbum> getAll() {

		return repo.findAll();
	}

}
