package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.MusicAlbum;
import com.cg.service.MusicAlbumService;

@RestController
public class AlbumController {

	@Autowired
	private MusicAlbumService sobj;

	@PostMapping(name = "/add", consumes = "application/json")
	public MusicAlbum addAlbum(@RequestBody MusicAlbum m) {
		return sobj.saveAlbum(m);
	}

	@GetMapping(path = "/get", produces = "application/json")
	public MusicAlbum getAlbum(@RequestParam("id") int albumId) {
		return sobj.get(albumId);
		 
	}

	@PutMapping(path = "/edit/{id}", consumes = "application/json")
	public MusicAlbum editAlbum(@PathVariable("id") int id, @RequestBody MusicAlbum mobj) {
		return sobj.update(id,mobj);
	}

	@DeleteMapping(path = "/delete/{id}")
	public String deleteAlbum(@PathVariable("id") int id) {
		return sobj.delete(id);
	}

	@GetMapping(path = "/all")
	public Iterable<MusicAlbum> getAll() {
		return sobj.getAll();
	}

}
