package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.MusicAlbum;
import java.util.List;

public interface MusicAlbumRepo extends CrudRepository<MusicAlbum, Integer> {

}
