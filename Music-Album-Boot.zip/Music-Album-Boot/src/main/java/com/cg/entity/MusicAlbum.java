package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "music_album")
public class MusicAlbum {

	@Id
	@GeneratedValue
	@Column(name = "album_id", length = 20)
	private int albumId;

	@Column(name = "album_title", length = 20)
	private String albumTitle;

	@Column(name = "album_artist", length = 20)
	private String albumAtrist;

	@Column(name = "album_price", length = 20)
	private double albumPrice;

	public int getAlbumId() {
		return albumId;
	}

	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	public String getAlbumAtrist() {
		return albumAtrist;
	}

	public void setAlbumAtrist(String albumAtrist) {
		this.albumAtrist = albumAtrist;
	}

	public double getAlbumPrice() {
		return albumPrice;
	}

	public void setAlbumPrice(double albumPrice) {
		this.albumPrice = albumPrice;
	}

	public MusicAlbum() {

	}

	public MusicAlbum(int albumId, String albumTitle, String albumAtrist, double albumPrice) {

		this.albumId = albumId;
		this.albumTitle = albumTitle;
		this.albumAtrist = albumAtrist;
		this.albumPrice = albumPrice;
	}
//
//	@Override
//	public String toString() {
//
//		return "Album Info : \nAlbum ID : " + albumId + "\nAlbum Title : " + albumTitle + "\nAlbum Artist : "
//				+ albumAtrist + "\nAlbum Price : " + albumPrice;
//	}

}
