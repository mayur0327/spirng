package com.cg.labOne3;

import java.util.List;


public class Sbu {
	private String sbuName, sbuHead, sbuCode;
	private List<Employee> empList;
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	public List<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	@Override
	public String toString() {
		return "Sbu sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", sbuCode=" + sbuCode + "\nEmployee Details-------\n" + empList;
	}
	
	
	
	
	
	

}
